polymorfismus

obsah a obvod čtverec a obdelník