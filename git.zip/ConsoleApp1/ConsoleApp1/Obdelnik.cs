﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Obdelnik : Ctverec
    {
        public int StranaB { get; private set; }
        public string Barva { get; private set; }
        public Obdelnik(int stranaA, string barva, int stranaB) : base(stranaA, barva)
        {
            StranaB = stranaB;
        }

        public override void Obvod()
        {
            int obvod = StranaA * 2 + StranaB * 2;
            Console.WriteLine("Obvod je:", obvod);
        }
        public override void Obsah()
        {
            int obsah = StranaA * StranaB;
            Console.WriteLine("Obvod je:", obsah);
        }


    }
}
