Vytvořte konzolový program v C#, který bude načítat čísla,
dokud nezadáte číslo 0, potom vytiskne součet všech těchto čísel
a aritmetický průměr všech zadaných hodnot.

Proveďte fork tohoto projektu, napojte si svůj projekt do VS,
první commit bude pojmenován založení projektu,
práci budete průběžně a smyslusplně commitovat.

