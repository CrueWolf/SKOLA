﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Auto
    {

       public string nazev;
       public string spz;
       public int pocetKm;
       public string spotreba;
           

        public Auto(string nazev, string spz, int pocetKm, string spotreba)
        {
            this.nazev = nazev;
            this.spz = spz;
            this.pocetKm = pocetKm;
            this.spotreba = spotreba;

        }

        public void Jede(int pocet)
        {
            pocetKm = pocet + pocetKm;
        }

        public void Info()
        {
            Console.WriteLine("blablabla " + nazev);
            Console.WriteLine("blablabla spz" + spz);
            Console.WriteLine("blablabla pocetKm" + pocetKm);
            Console.WriteLine("blablabla spotreba" + spotreba);

        }
    }
}
