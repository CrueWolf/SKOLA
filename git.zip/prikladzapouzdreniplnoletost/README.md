Program bude obsahovat třídu Clovek,
ta bude mít atributy a vlastnosti:

    - Jmeno
    - Prijmeni
    - Vek
    - Plnoletost

Atribut Plnoletost se nastaví automaticky na true, pokud je věk větší nebo roven 18.

Atributy lze měnit pouze uvnitř třídy, kromě věku, číst je lze napříč celým namespacem.