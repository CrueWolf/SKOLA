﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Ctverec
    {
        public int StranaA { get; private set; }
        public string Barva { get; private set; }
        public Ctverec(int stranaA, string barva) 
        {
            StranaA = stranaA;
            Barva = barva;
        }

        public virtual void Obsah()
        {
            Console.WriteLine("Obsah čtverce je:", StranaA * StranaA);
        }

        public virtual void Obvod()
        {
            Console.WriteLine("Obsah čtverce je:", 4 * StranaA);

        }

    }
}
