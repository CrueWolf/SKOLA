Vytvořte konzolový program v C#, který si vyžádá na vstupu Jméno a příjmení
člověka, poté se zeptá na jeho datum narození.
Jméno a příjmení zbaví mezer na začátku a na konci,
vypíše tento upravený řetězec a dále vypíše, 
kolik mu je právě teď let.

Pozor !!

Pokud je člověk narozen např. 19.12. a program je puštěn 10.12.
člověk ještě neměl narozeniny, rok se mu tedy ještě nepřičetl.
Pokud je puštěn v den jeho narozenin, již se počítá o rok víc.

Program vypracujte na Gitu, první commit je založení prázdného projektu,
průběžně smysluplně commitujte.....