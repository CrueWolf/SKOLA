﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Program na ukázku vytváření tříd
/// 
/// Vytvořte třídu student, každý student má jméno, příjmení, věk
/// a umí se představit - Umí vypsat na obrazovku: Jsem jmeno prijmeni a je mi vek let.
/// 
/// definujte třídu v souboru Program.cs, potom v samostatném souboru Student.cs
/// vytvořte třídu bez konstruktoru, pak vlastní konstruktor
/// 
/// </summary>
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
