﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*


            Ve třídě vytvořte metodu Info(), která vypíše do konzole všechny atributy instance.
            V Program.cs vytvořte dvě různé instance třídy Auto.cs.
            
            Zavolejte na nich metody Jede() a Info().


            První commit bude obsahovat založený nový projekt.*/
            string nazev;
            string spz;
            int pocetKm;
            string spotreba;

            Console.WriteLine("nazev");
            nazev = Console.ReadLine();

            Console.WriteLine("spz");
            spz = Console.ReadLine();

            Console.WriteLine("pocetKm");
            pocetKm = int.Parse (Console.ReadLine());

            Console.WriteLine("spotreba");
            spotreba = Console.ReadLine();

            Auto auto = new Auto(nazev, spz, pocetKm, spotreba);

            auto.Jede(12);
            auto.Info();

            Console.ReadKey();
        }

    }
}
