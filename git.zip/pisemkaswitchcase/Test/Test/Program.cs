﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dobrý den, jste registrovaným zákazníkem společnosti Ikea ?");
            Console.WriteLine("1.Ano");
            Console.WriteLine("2.Ne");

            int rozhod = int.Parse(Console.ReadLine());
            if (rozhod == 1) 
            {
                

                do
                {
                    menu();

                    rozhod = int.Parse(Console.ReadLine());

                    switch (rozhod)
                    {
                        case 1:
                            Console.WriteLine("(tel. č. 300 123 456\n");
                            break;
                        case 2:
                            Console.WriteLine("tel. č. 400 123 456\n");
                            break;
                        case 3:
                            Console.WriteLine("tel. č. 500 123 456\n");
                            break;
                        case 4:
                            Console.WriteLine(" tel. č. 600 123 456\n");
                            break;
                        case 10 :
                            Console.WriteLine("Ukončení programu\n");
                            break;

                        default:
                            Console.WriteLine("Zadal jsi špatnou volbu");
                            break;
                    }
                    Console.WriteLine("Děkujeme za využití našich služeb.");
                    Console.ReadKey();

                } while (rozhod != 10);
            }

            else if (rozhod == 2)
            {
                Console.WriteLine("Registrujte se prosím na tel.čísle: +420 02 345 6789");
            }
            else
            {
                Console.WriteLine("Neplatná volba");
            }

            Console.ReadKey();
        }

        static void menu()
        {
            Console.WriteLine("Menu:\n");

            Console.WriteLine("1. Kontakt na oddělení ložnicí");
            Console.WriteLine("2.Kontakt na oddělení kuchyní");
            Console.WriteLine("3.Kontakt na oddělení úložných prostor");
            Console.WriteLine("4.Kontakt na sjednání dopravy");
            Console.WriteLine("10. ukončení programu\n");
        }
    }
    

}
