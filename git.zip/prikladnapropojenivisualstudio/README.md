Tento projekt si forkněte,
zkopírujte si www adresu vašeho forknutého projektu
Ve visual studiu vyberte Klonovat projekt
Vložte adresu VAŠEHO projektu
Zkopírujte si adresu lokálního repozitáře
Vytvořte nový C# projekt ve visual studiu v lokálním repozitáři
Proveďte první commit
Commit pushněte do webového repozitáře
Zkontrolujte, že došlo k nahrání do weboveho repozitáře.