﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._1.IfElse
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("zadej svůj věk");
            int vek = int.Parse(Console.ReadLine());
            if (vek >= 18)
            {
                Console.WriteLine("Jste dospělý");
            }
            else
            {
                Console.WriteLine("Nejste dospělý");
            }




            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------------------");





            Console.WriteLine("zadej číslo které chceš porovnat");
            int prvni_cislo = int.Parse(Console.ReadLine());
            Console.WriteLine("zadej druhé číslo které chceš porovnat");
            int druhe_cislo = int.Parse(Console.ReadLine());

            if (prvni_cislo > druhe_cislo)
            {
                Console.WriteLine("prvni_cislo je vetsi nez druhe_cislo");
            }
            else
            {
                Console.WriteLine("druhe_cislo je vetsi nez prvni_cislo");
            }



            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------------------");



            Console.WriteLine("zadej číslo   ");
            int cislo3 = int.Parse(Console.ReadLine());
            Console.WriteLine("zadej druhé číslo   ");
            int cislo4 = int.Parse(Console.ReadLine());
            Console.WriteLine("matematickou operaci + nebo -");
            string operace = Console.ReadLine();
            if (operace == "+")
            {
                Console.WriteLine("Zadali jste plus");
                Console.WriteLine("{0} + {1} = {2}", cislo3, cislo4, cislo3 + cislo4);
            }
            if (operace == "-")
            {
                Console.WriteLine("Zadali jste mínus");

                Console.WriteLine("{0} - {1} = {2}", cislo3, cislo4, cislo3 + -cislo4);
            }



            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------------------");



            Console.ReadKey();
        }
    }
}