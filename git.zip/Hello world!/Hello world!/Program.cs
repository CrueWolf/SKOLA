﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello_world_
{
    class Program
    {
        static void Main(string[] args)
        {

            int cislo = 5;
            double mamut = 4.3;
            string retezec = "pabloooooooooo";
            bool logickahodnota = true;
            
           


            Console.WriteLine("hello pablo"+ cislo+"tohle se da na konec" );

            Console.WriteLine("obsah proménne cele cislo {0}, {1}, {2}", cislo, cislo, cislo);


            Console.ReadKey();

        }
    }
}
