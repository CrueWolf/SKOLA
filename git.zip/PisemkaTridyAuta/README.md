Vytvoř konzolový program v jazyce C#, který bude obsahovat třídu Auto.cs
v samostatném souboru.
Třída bude definovat atributy nazev, spz, pocetKm, spotreba.
Třída bude obsahovat vlastní konstruktor, který nastaví všechny atributy.
Třída dále bude obsahovat metodu Jede(), která jako vstupní parametr bude vyžadovat
celé číslo, představující počet kilometrů, které auto ujelo. Metoda navýší aktuální
stav kilometrů instance právě o tuto hodnotu.
Ve třídě vytvořte metodu Info(), která vypíše do konzole všechny atributy instance.

V Program.cs vytvořte dvě různé instance třídy Auto.cs. Zavolejte na nich metody
Jede() a Info().

Při psaní dodržujte obecné zásady OOP. Celé řešení průběžně commitujte v systému Git
do příslušného repozitáře!!!
První commit bude obsahovat založený nový projekt. 