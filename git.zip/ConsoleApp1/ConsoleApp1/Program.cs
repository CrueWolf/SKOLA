﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            Ctverec ctverec1 = new Ctverec(2, "red");
            Obdelnik obdelnik1 = new Obdelnik(2, "blue", 3);

        }
    }
}
