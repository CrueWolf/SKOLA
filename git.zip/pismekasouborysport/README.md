Vytvořte konzolový program v jazyce C#, který bude sloužit jako deníček sportovních aktivit.

Program bude sloužit k záznamu informací o běhu.

Uživatel chce ovládat program pomocí textového menu:

----------------------------------------------------
Menu:

1. Vložit info o běhu
2. Vypsat všechny uložené běhy
3. Smazat běh
4. Zobrazit všechny naběhané kilometry

k - ukončení aplikace

Vaše volba: 
------------------------------------------------------
------------------------------------------------------
O každém běhu chceme evidovat:

- datum kdy běh proběhl
- počet uběhnutých kilometrů
- čas - doba běhu (minuty:vteřiny)
- název trasy

------------------------------------------------------
-------------------------------------------------------
Volba 1 - vyzve uživatele k zadání hodnot a uložení do "databáze"
Volba 2 - Vypíše všechny informace o všech uložených bězích
Volba 3 - Vypíše očíslovaný seznam běhů a uživatel si vybere, který záznam se má odstranit
Volba 4 - Zobrazí součet všech naběhaných kilometrů

k - ukončí aplikaci
--------------------------------------------------------

program si zapamatuje údaje po ukončení programu

--------------------------------------------------------


Program zpracujte ve svém repozitáři, formknutím tohoto projektu,
průběžně commitujte, dodržujte zásady oop.
