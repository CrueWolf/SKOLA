Vytvořte konzolový program v jazyce C#, který bude sloužit jako
chatovací robot pro Zákaznickou linku Ikea :-)

Program přivítá uživatele slovy:

Dobrý den, jste registrovaným zákazníkem společnosti Ikea ?

1. ano
2. ne


Pokud uživatel odpoví ne, vypíše se:

Registrujte se prosím na tel. čísle: +420 02 345 6789


Pokud uživatel odpoví ano, zobrazí se následující menu:

Menu - kontakty

1. Kontakt na oddělení ložnicí

(tato volba zobrazí tel. č. 300 123 456)
zmáčknutím libovolné klávesy se vrátíte zpět do menu

2. Kontakt na oddělení kuchyní

(tato volba zobrazí tel. č. 400 123 456)
zmáčknutím libovolné klávesy se vrátíte zpět do menu

3. Kontakt na oddělení úložných prostor

(tato volba zobrazí tel. č. 500 123 456)
zmáčknutím libovolné klávesy se vrátíte zpět do menu


4. Kontakt na sjednání dopravy

(tato volba zobrazí tel. č. 600 123 456)
zmáčknutím libovolné klávesy se vrátíte zpět do menu


10. ukončení programu

Vaše volba: 


Pokud bude zadána nějaká neplatná volba, program na to upozorní uživatele
a znova vypíše menu.


Při ukončení programu se zobrazí hláška : 


Děkujeme za využití našich služeb.





Menu se bude vypisovat stále dokola, dokud uživatel program neukončí volbou 10.


Program vypracujete ve svých git repozitářích ve forknutém tomto projektu.
První commit bude založení nového projektu, dále smysluplně pojmenovávat commity.








