Vytvořte konzolový program sloužící k evidenci počítačových her.

Každá hra bude obsahovat údaje: 
    - název, 
    - rok vydání,
    - výrobce,
    - pegi, 
    - přístupnost. 
    Přístupnost se nastaví automaticky podle PEGI
    (0-7 - dětská hra, 8 - 17 mp, 18 - mn)


Hry bude možné do programu vkládat pomocí testového menu.

----------------------------------------------------------

Menu:

1. Vložit hru
2. Vypsat všechny hry
3. Výpis všech dětských her
4. Výpis her od zadaného výrobce

k - konec programu

