Vytvořte program, který bude obsahovat List zvirata.
Do listu můžeme vkládat instance tříd Delfin, Pes a jedno Vámi zvolené libovolné zvíře.
Všechny zvířata budou mít vlastnosti Jmeno(string),Vaha(int) a metodu Dychej()
Pes bude mít navíc Rasa(string) a metody Stekej(), delfíni Delka(int) a metodu Plav()
Použijte dědění a povinnost definovat metodu  Dychej() ve všech potomcích(abstraktní třídy a metody)
Vytvořte několik instancí tříd,
vložte je do listu zvirata.
List projděte a spočítejte kolik je jakých  zvířat.
Pokud bude v listu pes, představí  se jak se jmenuje a  zaštěká.