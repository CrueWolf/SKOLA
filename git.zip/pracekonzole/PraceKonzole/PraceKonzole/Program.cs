﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraceKonzole
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //definice proměnných
            int cislo = 2;
            double desecislo = 0.69;
            string retezec = "tohle je text proměnné řetězec";

            //výstup do konzole na obrazovku
            Console.WriteLine("tohle se vypíše na obrazovku:");

            //spojování řetězců
            Console.WriteLine("tohle je první řetězec" + "Tohle je druhý řetězec...");

            //tisk obsahu proměnné do konzole
            Console.WriteLine(retezec);
            Console.WriteLine("začátek vety" + cislo + "konec věty");
            Console.WriteLine("tohle je proměnná {0} \n tady je druhá proměnná {1}", cislo, desecislo);

            //vstup z konzole / náčítání hodnot z klávesnice
            //metoda readline vrátí načtenou hodnotu z klávesnice jako datový typ string
            
            Console.WriteLine("Zadej nějaké slovo já ho dvakrát zopakuji");
            string retezec1 = Console.ReadLine();
            Console.WriteLine("Zadal jsi:" + retezec1 + retezec1);


            //převedení hodnoty string z metody readline na datový typ int pomocí metody Parse
            int celecislo = int .Parse (Console.ReadLine());
            Console.WriteLine("dvojnásobek zadaného čísla je{0}", celecislo + celecislo);
            

            Console.WriteLine("Zadej nějaké číslo já ho umocním");
            double desetincislo = double.Parse(Console.ReadLine());
            Console.WriteLine("Zadal jsi:" + desetincislo * desetincislo);

            

            Console.WriteLine("zadej číslo které chceš násobit");
            int cislo1 = int.Parse(Console.ReadLine());
            Console.WriteLine("zadej počet násobků");
            int cislo2 = int.Parse(Console.ReadLine());

            for (int i = 1; i <= cislo2; i++) {

                Console.WriteLine("Násobky zadaného čísla je" + i * cislo2);
            }


            Console.ReadKey();

        }
    }
}
